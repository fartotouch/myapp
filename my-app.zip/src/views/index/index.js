import {
    Button,
    Cascader,
    Checkbox,
    Col,
    Form,
    Input,
    Row,
    Typography
  } from 'antd';
  import React from 'react';
  
  const { Title, Text, Link } = Typography;
  const Caption = (props) => {
    return (
      <div className="caption">
        <Title className="title" level={1}>北邮人就业信息中心</Title>
        <Title className="subtitle" level={5}>Usability and Maintainability</Title>
      </div>
    );
  }
  const educationBackground = [
    {
      value: 'grade',
      label: '所在年级',
      children: [
        {
          value: 'benke',
          label: '本科毕业生',
          
        },
        {
          value: 'shuoshi',
          label: '硕士毕业生',
          
        },
        {
          value: 'boshi',
          label: '博士毕业生',
          
        },
      ],
    },
    
  ];
  const formItemLayout = {
    labelCol: {
      xs: {
        span: 24,
      },
      sm: {
        span: 8,
      },
    },
    wrapperCol: {
      xs: {
        span: 24,
      },
      sm: {
        span: 16,
      },
    },
  };
  const tailFormItemLayout = {
    wrapperCol: {
      xs: {
        span: 24,
        offset: 0,
      },
      sm: {
        span: 16,
        offset: 8,
      },
    },
  };
    
   const onFinish = (values) => {
   console.log('Received values of form: ', values);
   };

   const Login = () => {
        const onFinish = (values) => {
          console.log('Success:', values);
        };
        const onFinishFailed = (errorInfo) => {
          console.log('Failed:', errorInfo);
        };
        return (
          <Form
            name="basic"
            labelCol={{
              span: 8,
            }}
            wrapperCol={{
              span: 16,
            }}
            initialValues={{
              remember: true,
            }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
          >
            <Form.Item
              label="用户名"
              name="username"
              rules={[
                {
                  required: true,
                  message: '请输入用户名',
                },
              ]}
            >
              <Input />
            </Form.Item>
      
            <Form.Item
              label="密码"
              name="password"
              rules={[
                {
                  required: true,
                  message: '请输入密码',
                },
              ]}
            >
              <Input.Password />
            </Form.Item>
      
            <Form.Item
              name="remember"
              valuePropName="checked"
              wrapperCol={{
                offset: 8,
                span: 16,
              }}
            >
              
            </Form.Item>
      
            <Form.Item
              wrapperCol={{
                offset: 8,
                span: 16,
              }}
            >
              <Button type="primary" htmlType="submit">
                登录
              </Button>
            </Form.Item>
          </Form>
        );
    };
  class Register extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        loading: false
      };
    }
  
    
  
    render() {
    return (
      <Form
        {...formItemLayout}
        name="register"
        onFinish={onFinish}
        initialValues={{
          educationBackground: ['所在年级', '本科毕业生'],
          
        }}
        scrollToFirstError
      >
        <Form.Item
          name="email"
          label="E-mail"
          rules={[
            {
              type: 'email',
              message: 'The input is not valid E-mail!',
            },
            {
              required: true,
              message: 'Please input your E-mail!',
            },
          ]}
        >
          <Input />
        </Form.Item>
  
        <Form.Item
          name="password"
          label="密码"
          rules={[
            {
              required: true,
              message: '请输入密码',
            },
          ]}
          hasFeedback
        >
          <Input.Password />
        </Form.Item>
  
        <Form.Item
          name="confirm"
          label="确认密码"
          dependencies={['password']}
          hasFeedback
          rules={[
            {
              required: true,
              message: '请输入密码',
            },
            ({ getFieldValue }) => ({
              validator(_, value) {
                if (!value || getFieldValue('password') === value) {
                  return Promise.resolve();
                }
                return Promise.reject(new Error('两次输入密码不一致'));
              },
            }),
          ]}
        >
          <Input.Password />
        </Form.Item>
  
        <Form.Item
          name="nickname"
          label="用户名"
          rules={[
            {
              required: true,
              message: '请输入用户名!',
              whitespace: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
  
        <Form.Item
          name="educationBackground"
          label="所在年级"
          rules={[
            {
              type: 'array',
              required: true,
              message: '请选择您的学历背景!',
            },
          ]}
        >
          <Cascader options={educationBackground} />
  
        </Form.Item>
  
        <Form.Item
          name="major"
          label="专业/研究方向"
          rules={[
            {
              required: true,
              message: 'Please input Intro',
            },
          ]}
        >
          <Input.TextArea showCount maxLength={100} />
        </Form.Item>
  
        
  
        <Form.Item label="Captcha" extra="We must make sure that your are a human.">
          <Row gutter={8}>
            <Col span={12}>
              <Form.Item
                name="captcha"
                noStyle
                rules={[
                  {
                    required: true,
                    message: 'Please input the captcha you got!',
                  },
                ]}
              >
                <Input />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Button>Get captcha</Button>
            </Col>
          </Row>
        </Form.Item>
  
        <Form.Item
          name="agreement"
          valuePropName="checked"
          rules={[
            {
              validator: (_, value) =>
                value ? Promise.resolve() : Promise.reject(new Error('Should accept agreement')),
            },
          ]}
          {...tailFormItemLayout}
        >
          <Checkbox>
            I have read the <a href="">agreement</a>
          </Checkbox>
        </Form.Item>
        <Form.Item {...tailFormItemLayout}>
          <Button type="primary" htmlType="submit">
            Register
          </Button>
        </Form.Item>
      </Form>
    );
    }
  }

  class Panel extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        status: "login"
      }
    }
 }
  const Index = (props) => {
    return (
      <div id="index">
        <Caption />
        <div className="panel">
          <Panel />
        </div>
      </div>
    );
  }
  export default Index;
  