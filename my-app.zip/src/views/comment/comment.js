const Comment = () => {
    return (
      <div>
        comment
      </div>
    );
  }
  
  export default Comment;