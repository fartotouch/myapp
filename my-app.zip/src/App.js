import { Routes, Route, Navigate } from "react-router-dom";
import { CustomRouter, history } from "cfgs/history";

import Index from 'views/index/index';
import Home from 'views/home/home';
import Overview from 'views/overview/overview';
import Business from 'views/business/business';
import Mainmap from 'views/mainmap/mainmap';
import Comment from 'views/comment/comment';
import Interactive from "views/interactive/interactive";
import Message from "views/message/message";

function App() {
  return (
    <CustomRouter history={history}>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="home" element={<Home />}>
          <Route path="overview" element={<Overview />} />
          <Route path="business" element={<Business />} />
          <Route path="mainmap" element={<Mainmap />} />
          <Route path="comment" element={<Comment />} />
          <Route path="interactive" element={<Interactive />} />
          <Route path="message" element={<Message />} />
        </Route>
      </Routes>
    </CustomRouter>
  );
}

export default App;